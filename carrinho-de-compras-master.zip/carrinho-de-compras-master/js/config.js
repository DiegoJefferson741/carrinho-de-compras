function setConfig(){
	var texts = {
		"title":"Carrinho de Compras"
	};
	document.title = texts.title;
	document.getElementById("navTitle").innerHTML = texts.title;
}

setConfig();